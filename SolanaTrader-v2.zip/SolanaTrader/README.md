# Solana Trader v2 — Android MVP

Cette version ajoute :
- connexion Binance Spot par API signée ;
- vérification de `/sapi/v1/account/apiRestrictions` ;
- refus du mode API si les retraits sont activés ;
- stockage chiffré local du secret API avec Android Keystore ;
- marchés Spot cotés en USDC récupérés dynamiquement ;
- convertisseur fiat ↔ USDC ;
- wallet Solana local avec nouvelle adresse Ed25519/Base58 ;
- mode PAPER par défaut ;
- backtest SMA crossover sur bougies 1h.

## Sécurité
Créer sur l'exchange une clé API dédiée avec lecture + trading Spot uniquement. **Désactiver les retraits, transferts, marge et futures.** Binance expose un endpoint `GET /sapi/v1/account/apiRestrictions` permettant de contrôler notamment `enableWithdrawals`, `enableReading` et `enableSpotAndMarginTrading`.

Pour un produit distribué à plusieurs utilisateurs, ne pas mettre les secrets API dans un serveur ou dans le code source : préférer un coffre de secrets / architecture backend. Pour un usage personnel, cette MVP chiffre le secret sur l'appareil avec Android Keystore.

## Compilation
Ouvrir dans Android Studio puis Build > Build APK(s). Le dépôt contient le wrapper Gradle minimal attendu, mais l'environnement de génération utilisé ici ne possède pas l'Android SDK/Gradle complet ; l'APK n'est donc pas joint comme binaire compilé.
