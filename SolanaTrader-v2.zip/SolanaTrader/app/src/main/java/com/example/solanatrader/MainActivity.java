package com.example.solanatrader;

import android.app.*;
import android.content.*;
import android.os.Bundle;
import android.text.InputType;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.util.*;
import javax.crypto.*;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import org.json.*;

public class MainActivity extends Activity {
    private LinearLayout marketList;
    private TextView balance, pnl, apiStatus;
    private static final String PREFS="wallet";
    private static final String PUB="pub", PRIV="priv", IV="iv";
    private static final String AES_ALIAS="SolanaTraderAES";
    private static final String API_KEY="binance_key", API_SECRET="binance_secret";
    private static final String BASE="https://api.binance.com";

    @Override public void onCreate(Bundle b) {
        super.onCreate(b); setContentView(R.layout.activity_main);
        marketList=findViewById(R.id.marketList); balance=findViewById(R.id.balance); pnl=findViewById(R.id.pnl); apiStatus=findViewById(R.id.apiStatus);
        findViewById(R.id.walletButton).setOnClickListener(v -> showWallet());
        findViewById(R.id.convertButton).setOnClickListener(v -> showConverter());
        findViewById(R.id.refreshMarkets).setOnClickListener(v -> loadMarkets());
        findViewById(R.id.exchangeButton).setOnClickListener(v -> showExchange());
        findViewById(R.id.backtestButton).setOnClickListener(v -> showBacktest());
        loadMarkets();
    }

    private void loadMarkets() {
        marketList.removeAllViews(); marketList.addView(txt("Chargement des marchés USDC…",0xff8f96a8,13));
        new Thread(() -> {
            try {
                JSONObject info = new JSONObject(httpGet(BASE+"/api/v3/exchangeInfo"));
                HashSet<String> allowed = new HashSet<>();
                JSONArray syms=info.getJSONArray("symbols");
                for(int i=0;i<syms.length();i++) { JSONObject s=syms.getJSONObject(i); if("TRADING".equals(s.optString("status")) && "USDC".equals(s.optString("quoteAsset"))) allowed.add(s.optString("symbol")); }
                JSONArray a=new JSONArray(httpGet(BASE+"/api/v3/ticker/24hr")); ArrayList<Market> ms=new ArrayList<>();
                for(int i=0;i<a.length();i++){ JSONObject o=a.getJSONObject(i); String sym=o.optString("symbol"); if(allowed.contains(sym)) ms.add(new Market(sym,o.optString("lastPrice"),o.optString("priceChangePercent"),o.optString("quoteVolume"))); }
                ms.sort((x,y)->Double.compare(safe(y.vol),safe(x.vol)));
                runOnUiThread(() -> renderMarkets(ms));
            } catch(Exception e) { runOnUiThread(() -> { marketList.removeAllViews(); marketList.addView(txt("Marchés indisponibles : "+e.getMessage(),0xffff4d72,12)); }); }
        }).start();
    }
    private double safe(String s){ try{return Double.parseDouble(s);}catch(Exception e){return 0;} }
    private void renderMarkets(ArrayList<Market> ms){
        marketList.removeAllViews();
        if(ms.isEmpty()){marketList.addView(txt("Aucun marché USDC disponible.",0xff8f96a8,13));return;}
        int n=Math.min(ms.size(),100);
        for(int i=0;i<n;i++){ Market m=ms.get(i); LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); row.setPadding(14,14,14,14); row.setBackgroundColor(0xff121522);
            TextView name=txt(m.sym,0xffffffff,15), price=txt("$"+m.price,0xffffffff,13), ch=txt(m.change+"%",safe(m.change)>=0?0xff36e58b:0xffff4d72,12);
            row.addView(name,new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1)); row.addView(price); row.addView(ch,new LinearLayout.LayoutParams(90,ViewGroup.LayoutParams.WRAP_CONTENT)); marketList.addView(row); Space sp=new Space(this); marketList.addView(sp,new LinearLayout.LayoutParams(1,2)); }
    }
    private TextView txt(String s,int color,float size){TextView t=new TextView(this);t.setText(s);t.setTextColor(color);t.setTextSize(size);t.setGravity(Gravity.CENTER_VERTICAL);t.setPadding(5,0,5,0);return t;}

    private void showWallet(){
        try { String address=getOrCreateSolanaAddress();
            LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(30,10,30,0);
            box.addView(txt("Adresse Solana — dépôt USDC (SPL)",0xffffffff,18));
            TextView addr=txt(address,0xff32e6ff,13); addr.setTextIsSelectable(true); box.addView(addr);
            box.addView(txt("Adresse générée localement. La clé privée n'est jamais affichée. Utilise uniquement le réseau Solana et vérifie le token avant d'envoyer des fonds.",0xff8f96a8,12));
            new AlertDialog.Builder(this).setView(box).setPositiveButton("Copier",(d,w)->{((android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(android.content.ClipData.newPlainText("Solana",address)); Toast.makeText(this,"Adresse copiée",Toast.LENGTH_SHORT).show();}).setNegativeButton("Fermer",null).show();
        } catch(Exception e){new AlertDialog.Builder(this).setTitle("Wallet").setMessage("Création impossible : "+e.getMessage()).setPositiveButton("OK",null).show();}
    }
    private String getOrCreateSolanaAddress() throws Exception {
        android.content.SharedPreferences p=getSharedPreferences(PREFS,0); String existing=p.getString(PUB,null); if(existing!=null)return existing;
        KeyPairGenerator kpg=KeyPairGenerator.getInstance("Ed25519"); KeyPair kp=kpg.generateKeyPair(); byte[] x=kp.getPublic().getEncoded(); byte[] raw=Arrays.copyOfRange(x,x.length-32,x.length); String addr=Base58.encode(raw);
        ensureAes(); Cipher c=Cipher.getInstance("AES/GCM/NoPadding"); KeyStore ks=KeyStore.getInstance("AndroidKeyStore"); ks.load(null); javax.crypto.SecretKey aes=(javax.crypto.SecretKey)ks.getKey(AES_ALIAS,null);
        c.init(Cipher.ENCRYPT_MODE,aes); byte[] enc=c.doFinal(kp.getPrivate().getEncoded());
        p.edit().putString(PUB,addr).putString(PRIV,Base64.getEncoder().encodeToString(enc)).putString(IV,Base64.getEncoder().encodeToString(c.getIV())).apply(); return addr;
    }
    private void ensureAes() throws Exception { KeyStore ks=KeyStore.getInstance("AndroidKeyStore"); ks.load(null); if(ks.containsAlias(AES_ALIAS))return; KeyGenerator kg=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore"); kg.init(new KeyGenParameterSpec.Builder(AES_ALIAS,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build()); kg.generateKey(); }

    private void showConverter(){
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(30,10,30,0);
        Spinner from=new Spinner(this); String[] currencies={"EUR","USD","GBP","CHF","CAD","JPY","USDC"}; from.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,currencies));
        Spinner to=new Spinner(this); to.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"USDC","USD","EUR","GBP","CHF","CAD","JPY"}));
        EditText amount=new EditText(this); amount.setHint("Montant"); amount.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
        TextView result=txt("Résultat : —",0xff32e6ff,15); box.addView(from);box.addView(to);box.addView(amount);box.addView(result);
        new AlertDialog.Builder(this).setTitle("Convertisseur dépôt").setView(box).setPositiveButton("Calculer",(d,w)->convert(amount.getText().toString(),(String)from.getSelectedItem(),(String)to.getSelectedItem(),result)).setNegativeButton("Fermer",null).show();
    }
    private void convert(String amount,String from,String to,TextView result){ new Thread(()->{try{double a=Double.parseDouble(amount.replace(',','.')); if(from.equals(to)){set(result,"Résultat : "+a+" "+to);return;} String base=from.equals("USDC")?"USD":from; URL u=new URL("https://api.frankfurter.app/latest?from="+URLEncoder.encode(base,"UTF-8")); JSONObject o=new JSONObject(httpGet(u.toString())); double rate;
            if(to.equals("USDC")){rate=base.equals("USD")?1.0:1.0/o.getJSONObject("rates").optDouble("USD",1);} else if(from.equals("USDC")){rate=to.equals("USD")?1.0:o.getJSONObject("rates").optDouble(to,1);} else rate=o.getJSONObject("rates").optDouble(to,1);
            set(result,String.format(Locale.US,"Résultat : %.6f %s",a*rate,to)); }catch(Exception e){set(result,"Conversion indisponible : "+e.getMessage());}}).start(); }

    private void showExchange(){
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(24,8,24,0);
        EditText key=new EditText(this); key.setHint("Binance API Key"); key.setSingleLine(true);
        EditText secret=new EditText(this); secret.setHint("Binance API Secret"); secret.setSingleLine(true); secret.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
        TextView warn=txt("Sécurité : crée une clé API avec lecture + trading Spot uniquement. Désactive les retraits, transferts et futures. L'app vérifie /sapi/v1/account/apiRestrictions avant d'autoriser le mode réel.",0xffffc857,12);
        box.addView(key);box.addView(secret);box.addView(warn);
        android.content.SharedPreferences p=getSharedPreferences(PREFS,0); key.setText(p.getString(API_KEY,""));
        new AlertDialog.Builder(this).setTitle("Connexion Exchange — Binance Spot").setView(box).setPositiveButton("Tester / enregistrer",(d,w)->saveAndTestApi(key.getText().toString().trim(),secret.getText().toString())).setNegativeButton("Fermer",null).show();
    }
    private void saveAndTestApi(String key,String secret){
        if(key.isEmpty()||secret.isEmpty()){toast("Clé API et secret requis");return;}
        try { ensureAes(); saveSecret(secret); getSharedPreferences(PREFS,0).edit().putString(API_KEY,key).apply(); } catch(Exception e){toast("Stockage sécurisé impossible");return;}
        setApiStatus("Test de la clé API…",0xffffc857);
        new Thread(()->{try{
            String restrictions=signedGet("/sapi/v1/account/apiRestrictions",key,secret); JSONObject r=new JSONObject(restrictions);
            boolean withdraw=r.optBoolean("enableWithdrawals",false), trade=r.optBoolean("enableSpotAndMarginTrading",false), read=r.optBoolean("enableReading",false);
            String msg="Lecture="+read+" • Spot="+trade+" • Retraits="+withdraw;
            if(withdraw) { setApiStatus("REFUSÉ : retraits activés — "+msg,0xffff4d72); }
            else if(!read){setApiStatus("REFUSÉ : lecture API désactivée",0xffff4d72);}
            else {setApiStatus("Clé protégée : "+msg, trade?0xff36e58b:0xff32e6ff);}
        }catch(Exception e){setApiStatus("Erreur API : "+e.getMessage(),0xffff4d72);} }).start();
    }
    private void setApiStatus(String s,int color){runOnUiThread(()->{apiStatus.setText(s);apiStatus.setTextColor(color);});}

    private void showBacktest(){
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(24,8,24,0);
        EditText symbol=new EditText(this); symbol.setHint("Symbole USDC, ex. BTCUSDC"); symbol.setText("BTCUSDC");
        EditText days=new EditText(this); days.setHint("Nombre de bougies 1h (max 1000)"); days.setText("500"); days.setInputType(InputType.TYPE_CLASS_NUMBER);
        EditText fast=new EditText(this); fast.setHint("SMA rapide"); fast.setText("20"); fast.setInputType(InputType.TYPE_CLASS_NUMBER);
        EditText slow=new EditText(this); slow.setHint("SMA lente"); slow.setText("50"); slow.setInputType(InputType.TYPE_CLASS_NUMBER);
        TextView result=txt("Résultat : —",0xff32e6ff,13); box.addView(symbol);box.addView(days);box.addView(fast);box.addView(slow);box.addView(result);
        new AlertDialog.Builder(this).setTitle("Backtest — stratégie SMA crossover").setView(box).setPositiveButton("Lancer",(d,w)->runBacktest(symbol.getText().toString().trim().toUpperCase(Locale.US),parseInt(days.getText().toString(),500),parseInt(fast.getText().toString(),20),parseInt(slow.getText().toString(),50),result)).setNegativeButton("Fermer",null).show();
    }
    private int parseInt(String s,int def){try{return Integer.parseInt(s);}catch(Exception e){return def;}}
    private void runBacktest(String symbol,int limit,int fast,int slow,TextView result){
        if(limit<100)limit=100; if(limit>1000)limit=1000; if(fast<2)fast=2; if(slow<=fast)slow=fast+1;
        final int L=limit,F=fast,S=slow;
        set(result,"Backtest en cours…");
        new Thread(()->{try{
            String raw=httpGet(BASE+"/api/v3/klines?symbol="+URLEncoder.encode(symbol,"UTF-8")+"&interval=1h&limit="+L); JSONArray a=new JSONArray(raw); ArrayList<Double> close=new ArrayList<>(); for(int i=0;i<a.length();i++)close.add(a.getJSONArray(i).getDouble(4));
            double cash=1000, asset=0, entry=0; int trades=0,wins=0; double peak=1000,maxDd=0;
            for(int i=S;i<close.size();i++){double sf=avg(close,i-F+1,i), ss=avg(close,i-S+1,i), pf=avg(close,i-F,i-1), ps=avg(close,i-S,i-1); double p=close.get(i);
                if(asset==0 && pf<=ps && sf>ss){asset=cash/p; cash=0;entry=p;trades++;}
                else if(asset>0 && pf>=ps && sf<ss){cash=asset*p;asset=0;if(p>entry)wins++;}
                double equity=cash+asset*p; peak=Math.max(peak,equity);maxDd=Math.max(maxDd,(peak-equity)/peak);
            }
            double finalEq=cash+asset*close.get(close.size()-1), ret=(finalEq/1000-1)*100;
            if(asset>0){trades++;}
            String out=String.format(Locale.US,"Capital initial 1 000 USDC\nCapital final %.2f USDC\nRendement %.2f %%\nTrades %d • gagnants %d\nDrawdown max %.2f %%\nSMA %d/%d • 1h",finalEq,ret,trades,wins,maxDd*100,F,S); set(result,out);
        }catch(Exception e){set(result,"Backtest impossible : "+e.getMessage());}}
        ).start();
    }
    private double avg(ArrayList<Double> x,int from,int to){double sum=0;for(int i=from;i<=to;i++)sum+=x.get(i);return sum/(to-from+1);}

    private String signedGet(String path,String key,String secret) throws Exception { long ts=System.currentTimeMillis(); String q="timestamp="+ts+"&recvWindow=5000"; String sig=hmac(q,secret); return httpGet(BASE+path+"?"+q+"&signature="+sig,key); }
    private String hmac(String data,String secret) throws Exception { javax.crypto.Mac mac=javax.crypto.Mac.getInstance("HmacSHA256"); mac.init(new SecretKeySpec(secret.getBytes(StandardCharsets.UTF_8),"HmacSHA256")); byte[] b=mac.doFinal(data.getBytes(StandardCharsets.UTF_8)); StringBuilder s=new StringBuilder();for(byte x:b)s.append(String.format(Locale.US,"%02x",x));return s.toString(); }
    private String httpGet(String url) throws Exception{return httpGet(url,null);}
    private String httpGet(String url,String key) throws Exception { HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();c.setConnectTimeout(10000);c.setReadTimeout(10000);if(key!=null)c.setRequestProperty("X-MBX-APIKEY",key);int code=c.getResponseCode();InputStream in=code>=400?c.getErrorStream():c.getInputStream();BufferedReader r=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8));StringBuilder s=new StringBuilder(),line;while((line=r.readLine())!=null)s.append(line);r.close();if(code>=400)throw new IOException("HTTP "+code+" "+s);return s.toString();}

    private void saveSecret(String secret) throws Exception { ensureAes(); Cipher c=Cipher.getInstance("AES/GCM/NoPadding");KeyStore ks=KeyStore.getInstance("AndroidKeyStore");ks.load(null);javax.crypto.SecretKey aes=(javax.crypto.SecretKey)ks.getKey(AES_ALIAS,null);c.init(Cipher.ENCRYPT_MODE,aes);byte[] enc=c.doFinal(secret.getBytes(StandardCharsets.UTF_8));getSharedPreferences(PREFS,0).edit().putString("secret_enc",Base64.getEncoder().encodeToString(enc)).putString("secret_iv",Base64.getEncoder().encodeToString(c.getIV())).apply(); }
    private String getSecret() throws Exception {String e=getSharedPreferences(PREFS,0).getString("secret_enc",null),iv=getSharedPreferences(PREFS,0).getString("secret_iv",null);if(e==null||iv==null)return null;KeyStore ks=KeyStore.getInstance("AndroidKeyStore");ks.load(null);javax.crypto.SecretKey aes=(javax.crypto.SecretKey)ks.getKey(AES_ALIAS,null);Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.DECRYPT_MODE,aes,new GCMParameterSpec(128,Base64.getDecoder().decode(iv)));return new String(c.doFinal(Base64.getDecoder().decode(e)),StandardCharsets.UTF_8);}
    private void toast(String s){runOnUiThread(()->Toast.makeText(this,s,Toast.LENGTH_LONG).show());}
    private void set(TextView v,String s){runOnUiThread(()->v.setText(s));}

    static class Market{String sym,price,change,vol;Market(String a,String b,String c,String d){sym=a;price=b;change=c;vol=d;}}
    static class Base58{private static final char[] A="123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz".toCharArray(); static String encode(byte[] in){if(in.length==0)return "";byte[] x=Arrays.copyOf(in,in.length);StringBuilder out=new StringBuilder();int zeros=0;while(zeros<x.length&&x[zeros]==0)zeros++;int start=zeros;while(start<x.length){int rem=0;for(int i=start;i<x.length;i++){int n=(x[i]&255)+(rem<<8);x[i]=(byte)(n/58);rem=n%58;}out.append(A[rem]);while(start<x.length&&x[start]==0)start++;}for(int i=0;i<zeros;i++)out.append('1');return out.reverse().toString();}}
}
